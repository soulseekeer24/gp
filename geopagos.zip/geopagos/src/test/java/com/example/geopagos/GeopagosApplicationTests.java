package com.example.geopagos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeopagosApplicationTests {

	@Test
	void contextLoads() {
	}

}
